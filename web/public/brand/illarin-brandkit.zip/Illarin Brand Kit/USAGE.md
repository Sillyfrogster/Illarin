# Illarin brand assets

Illarin is a catalog for the AI-roleplay community's characters, lorebooks,
presets, themes and packs. Its butterfly mark represents the connection between
creators, their ideas and the worlds they make.

## Choose a logo

Use the horizontal logo wherever the name needs to be read. Use the standalone
mark in compact spaces where Illarin is already identified.

| Background | Monochrome | Colour |
| --- | --- | --- |
| Light | `logos/illarin-horizontal-black.svg` | `logos/illarin-horizontal-on-light.svg` |
| Dark | `logos/illarin-horizontal-white.svg` | `logos/illarin-horizontal-on-dark.svg` |

The SVGs contain outlined shapes and lettering. No font installation is needed.
PNG exports sit beside the SVGs. Use SVG for websites and scalable layouts;
use PNG where an application requires a bitmap.

Keep the supplied proportions, spacing and colours. Leave clear space around
the visible logo equal to at least one quarter of the mark's height. Use the
horizontal logo at 128 px wide or larger. Below that, use the mark or favicon.

Place the logo on an uncluttered area with clear contrast. Do not stretch,
rotate, outline, blur or add shadows to it. Use the supplied icon background
when the mark needs to stand apart from busy imagery.

## Colours and type

| Colour | Hex |
| --- | --- |
| Black | `#0A0A0A` |
| White | `#FFFFFF` |
| Violet | `#7C3AED` |
| Dark violet | `#6D28D9` |
| Light violet | `#B89AFF` |

Violet is the main accent. Use dark violet on light backgrounds and light
violet on dark backgrounds where the coloured mark needs stronger contrast.
Outfit is the display typeface; DM Sans is the supporting typeface. Use the
supplied wordmark artwork instead of typing the name to recreate the logo.

## Partners

The `partners/` folder contains “Available on Illarin” badges in light and dark
versions. Display a badge at 240 px wide or larger so its supporting line stays
readable. Link it to the relevant Illarin destination when used on a website.

The `templates/` folder shows how the Illarin lockup can sit beside another
identity. “Partner” is a placeholder to replace with the partner's own mark.
Give both identities clear space and comparable visual weight. The separator
belongs between them, outside each identity's clear space.

## Icons

- `icons/favicon.svg` is the scalable browser icon. `favicon.ico` contains
  16, 32 and 48 px versions; individual PNGs also include 64 px.
- `icons/apple-touch-icon.png` is 180 × 180.
- `icons/icon-192.png` and `icons/icon-512.png` are square web-app icons.
- `icons/app-icon-maskable.png` leaves the mark inside the central safe area.
- `icons/app-icon.png` is the full 1024 × 1024 square. The rounded version is
  available for placements that need a finished background shape.
- `icons/site.webmanifest` references the included web-app icons using paths
  relative to the manifest. Keep those files together when copying it.

## Campaign artwork

“Worlds worth sharing.” is the campaign line. Social graphics are supplied at
1200 × 630, 1080 × 1080 and 1080 × 1920, with matching SVG sources.

The doorway illustration is a separate image with no text or logo. Keep its
proportions when placing it. It is brand artwork, separate from creator covers.
